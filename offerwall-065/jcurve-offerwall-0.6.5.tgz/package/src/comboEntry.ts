/** Ways into 「포인트 빨리 모으기」: Chance-tab chip, Home banner, and a route that popups / pushes / deep links can fire. */
import type { ReactElement } from 'react';
import { COMBO_NAME, ComboGuideScreen, DEFAULT_COMBO_THEME, comboPopupContent, formatGoal, hasComboRows, missionRowsOf, needsTrialConsent, popupHeadlineSizes, trialMissions, useTodayCombos } from './combos';
import type { ComboBundle, ComboMission, ComboTheme, ComboTrial, TodayCombos } from './combos';
import { COMBO_CONSENT_TOAST, COMBO_CONSENT_TOAST_OFF, COMBO_TRIALS_NAME, ComboTrialsScreen, TrialConsentPopup, listenForTrialRequests, parseMyTrials, trialNoticeDeclineKey, useTrialNoticeAgreed } from './comboTrials';
import type { ConsentAnswer, MyTrial, TrialNotifyResult } from './comboTrials';
import { findCampaignKey, nativeCampaignApi, nativeCopyText } from './campaigns';
import type { CampaignApi, CampaignInfo } from './campaigns';
import { useDoneMissions } from './comboDone';
import { addOfferwallNativeListener } from './native';
import type { ComboStorage } from './comboDone';
import { popupStorageKey, usePulse, useSeenToday } from './comboSeen';
import { getChanceTab, getChanceTabInset, isWallLoaded, onChanceTab, onChanceTabInset, onWallState } from './wallSignal';
import { useChanceProviders } from './chanceProviders';
import { SNAPPLAY_PROVIDER_ID, openSnapPlayAd, readSnapPlayAds } from './snapPlay';
import { comboSheetProbe, resetComboSheetProbe } from './comboSheetProbe';
import type { SnapPlayAd, SnapPlayOpenResult } from './snapPlay';
import { openOfferwall } from './index';

/** 0.6.2 bundle mark — a deploy check can look for it to tell a build whose 「포인트 빨리 모으기」 follows the 찬스1 / 찬스2 tab. */
export const OFFERWALL_FAST_COMBOS_TABS_MARK = 'jcurve-offerwall-fast-combos-tabs:v1';

/** Route name for pushes (`data.go`) and links. Apps use in-app actions, not a URL scheme. */
export const COMBOS_ROUTE = 'offerwall/combos';
/** Server popups store their action in a 10-character column, so the popup action is this short form. */
export const COMBOS_POPUP_ACTION = 'combos';
/** Accepts 'offerwall/combos', '/offerwall/combos?from=push', 'myapp://offerwall/combos' and the popup action 'combos'. */
export function isCombosRoute(value: unknown): boolean {
  if (typeof value !== 'string') return false;
  const path = value.trim().replace(/^[a-z][a-z0-9+.-]*:\/\//i, '').replace(/^\/+/, '').split(/[?#]/)[0].replace(/\/+$/, '');
  return path === COMBOS_ROUTE || path === COMBOS_POPUP_ACTION;
}

type Opener = { priority: number; open(): void };
const openers = new Set<Opener>();
let waitingSince = 0;
const WAIT_MS = 10000;

/**
 * Opens the guide from anywhere (popup button, push tap, link). If no entry is mounted yet, for example while the app
 * switches tabs, the request waits up to 10 seconds for the first one that mounts. Returns true when an entry took it.
 */
export function requestOpenCombos(now: number = Date.now()): boolean {
  let target: Opener | undefined;
  // Ties go to the most recently mounted one: a screen that just appeared is the likelier one on display.
  for (const opener of openers) if (!target || opener.priority >= target.priority) target = opener;
  if (!target) { waitingSince = now; return false; }
  waitingSince = 0;
  target.open();
  return true;
}
/** Chance tab (2) wins over Home (1) so one request never opens two screens. */
export function listenForComboRequests(opener: Opener, now: number = Date.now()): () => void {
  openers.add(opener);
  const waiting = waitingSince && now - waitingSince <= WAIT_MS;
  waitingSince = 0;
  if (waiting) opener.open();
  return () => { openers.delete(opener); };
}

/**
 * Where the chip sits, in points from the top-right of the wall's container. Measured on two captures of the wall's own
 * header row (iPhone 402pt wide, Galaxy A32 411dp wide): row ~48 high, profile icon centered ~24 down and its left edge
 * ~44 from the right, so a 36-high chip 8 left of the icon is top 6 / right 52. The header stays fixed when the list scrolls.
 */
export const COMBO_CHIP_TOP = 6;
/** The wall's own title (「리워드 충전소」) ends about this far from the left edge (iPhone 402pt and Galaxy A32 411dp captures: 145~150). */
export const COMBO_TITLE_END = 150;
/** Space kept between that title and our buttons. */
export const COMBO_TITLE_GAP = 8;
/** Space between the 「무료체험」 button and the chip. */
export const COMBO_CHIP_GAP = 8;

/**
 * How the two buttons of the chip row are drawn. 대표님 10/27 23:06 「버튼 크기 동일하게」: the 「무료체험」 button and the chip have the same height, the
 * same width, the same font size and the same rounding; only the colours differ (white with a yellow rim / yellow).
 */
export type ComboChipFit = { chipLabel: string; pillLabel: string; size: number; pad: number; width: number; height: number };
/** Rough text width in points: Hangul about 0.95 em (bold, a little more than measured so nothing is cut), a space 0.3 em, anything else 0.62 em. */
const textWidth = (text: string, size: number): number => [...text].reduce((sum, ch) => sum + (/[\uAC00-\uD7A3]/.test(ch) ? 0.95 : /\s/.test(ch) ? 0.3 : 0.62), 0) * size;
/** Height of both buttons when they sit side by side. */
export const COMBO_CHIP_PAIR_HEIGHT = 34;
/**
 * With the 「무료체험」 button beside it the row must not run into the wall's title (`COMBO_TITLE_END` + 8 from the left). Tries these in order and keeps
 * the first whose two equal-width buttons fit between the title and the chip's right edge: both in full, then 「빨리 모으기」 at smaller and smaller sizes
 * (both buttons shrink together), then the short words 「모으기」 / 「체험」 for the narrowest phones (the screen reader still hears the full names).
 * `width` is the screen width, `right` the chip's right offset.
 */
export function comboChipFit(width: number, right: number): ComboChipFit {
  const room = width - right - COMBO_TITLE_END - COMBO_TITLE_GAP;
  const options: Array<Omit<ComboChipFit, 'width' | 'height'>> = [
    { chipLabel: COMBO_NAME, pillLabel: '무료체험', size: 14, pad: 11 },
    { chipLabel: '빨리 모으기', pillLabel: '무료체험', size: 13, pad: 10 },
    { chipLabel: '빨리 모으기', pillLabel: '무료체험', size: 12, pad: 9 },
    { chipLabel: '빨리 모으기', pillLabel: '무료체험', size: 11, pad: 8 },
    { chipLabel: '모으기', pillLabel: '체험', size: 11, pad: 8 },
    { chipLabel: '모으기', pillLabel: '체험', size: 10.5, pad: 6 },
  ];
  // the chip also carries its arrow (›, or ✕ when open) and a 4 point gap; both buttons have a 1.5 point rim
  const widthOf = (o: Omit<ComboChipFit, 'width' | 'height'>): number =>
    Math.ceil(Math.max(textWidth(o.chipLabel, o.size) + o.size * 0.6 + 4, textWidth(o.pillLabel, o.size)) + 2 * o.pad + 3);
  const pick = options.find(o => 2 * widthOf(o) + COMBO_CHIP_GAP <= room) ?? options[options.length - 1];
  return { ...pick, width: widthOf(pick), height: COMBO_CHIP_PAIR_HEIGHT };
}
export const COMBO_CHIP_RIGHT = 52;
export const COMBO_SHEET_TOP = 52;

export type ComboChipProps = { onPress: () => void; open?: boolean; theme?: ComboTheme; top?: number; right?: number; /** Animated opacity for the blink (see usePulse). */ opacity?: import('react-native').Animated.Value; /** drawn to the chip's left in the same row (the 「무료체험 확인」 button) */ before?: ReactElement | null; /** size, words and width shared with the button beside it (see comboChipFit) */ fit?: ComboChipFit };
/**
 * Small chip that floats over the wall's own header row, left of its profile icon. Only the chip is drawn: no band,
 * no padding box, and the wrapper lets touches through everywhere else.
 */
export function ComboChip({ onPress, open = false, theme = DEFAULT_COMBO_THEME, top = COMBO_CHIP_TOP, right = COMBO_CHIP_RIGHT, opacity, before, fit }: ComboChipProps): ReactElement {
  const React = require('react') as typeof import('react');
  const { View, Text, Pressable, Animated } = require('react-native') as typeof import('react-native');
  const h = React.createElement;
  const t = theme;
  const pressable = h(Pressable, {
    accessibilityRole: 'button', accessibilityLabel: COMBO_NAME, accessibilityState: { expanded: open }, onPress, hitSlop: 6,
    style: ({ pressed }: { pressed: boolean }): import('react-native').ViewStyle => ({
      height: fit ? fit.height : 36, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, paddingHorizontal: fit ? fit.pad : 14, borderRadius: t.radius.chip,
      backgroundColor: t.accent, opacity: pressed ? 0.8 : 1, ...(fit ? { width: fit.width, borderWidth: 1.5, borderColor: t.accent } : {}), ...t.shadow,
    }),
  },
    h(Text, { numberOfLines: 1, style: { fontSize: fit ? fit.size : t.font.small, fontWeight: '900', color: t.text } }, fit ? fit.chipLabel : COMBO_NAME),
    h(Text, { accessible: false, style: { fontSize: fit ? fit.size : t.font.small, fontWeight: '900', color: t.accentText } }, open ? '✕' : '›'));
  return h(View, { pointerEvents: 'box-none', style: { position: 'absolute', top, right, zIndex: 30, elevation: 30, flexDirection: 'row', alignItems: 'center', gap: COMBO_CHIP_GAP } },
    before ?? null,
    opacity ? h(Animated.View, { style: { opacity } }, pressable) : pressable);
}

/**
 * 「무료체험 확인」 (대표님 10/27 22:11): a small button to the left of the chip that opens the member's own free-trial list. Short on purpose
 * (the wall's title is to its left): white with a yellow rim, so it does not compete with the chip.
 */
export function ComboTrialsChip({ onPress, open = false, theme = DEFAULT_COMBO_THEME, fit }: { onPress: () => void; open?: boolean; theme?: ComboTheme; fit?: ComboChipFit }): ReactElement {
  const React = require('react') as typeof import('react');
  const { Text, Pressable } = require('react-native') as typeof import('react-native');
  const t = theme;
  return React.createElement(Pressable, {
    key: 'trials-chip', accessibilityRole: 'button', accessibilityLabel: COMBO_TRIALS_NAME, accessibilityState: { expanded: open }, onPress, hitSlop: 6,
    style: ({ pressed }: { pressed: boolean }): import('react-native').ViewStyle => ({
      height: fit ? fit.height : 30, paddingHorizontal: fit ? fit.pad : 9, borderRadius: t.radius.chip, alignItems: 'center', justifyContent: 'center',
      ...(fit ? { width: fit.width } : {}),
      backgroundColor: open ? t.accentSoft : '#FFFFFF', borderWidth: 1.5, borderColor: t.accent, opacity: pressed ? 0.8 : 1,
    }),
  }, React.createElement(Text, { numberOfLines: 1, style: { fontSize: fit ? fit.size : 12, fontWeight: '900', color: t.accentText } }, fit ? fit.pillLabel : '무료체험'));
}

export type ComboBannerProps = { combos: TodayCombos; onPress: () => void; theme?: ComboTheme; /** Animated opacity for the blink (see usePulse). */ opacity?: import('react-native').Animated.Value };
/** Home banner: the name large, the goal numbers emphasized. */
export function ComboBanner({ combos, onPress, theme = DEFAULT_COMBO_THEME, opacity }: ComboBannerProps): ReactElement {
  const React = require('react') as typeof import('react');
  const { View, Text, Pressable, Animated } = require('react-native') as typeof import('react-native');
  const h = React.createElement;
  const t = theme;
  const goals = combos.bundles.map(b => formatGoal(b.goal));
  const pressable = h(Pressable, {
    accessibilityRole: 'button',
    accessibilityLabel: `${COMBO_NAME}, ${goals.join(', ')} 목표별로 보기`,
    onPress,
    style: ({ pressed }: { pressed: boolean }): import('react-native').ViewStyle => ({
      marginHorizontal: 16, marginVertical: 8, padding: 16, borderRadius: t.radius.card, flexDirection: 'row', alignItems: 'center',
      backgroundColor: t.card, borderWidth: 1.5, borderColor: t.line, opacity: pressed ? 0.85 : 1, ...t.shadow,
    }),
  },
    h(View, { style: { flex: 1, minWidth: 0, paddingRight: 8 } },
      h(Text, { numberOfLines: 1, style: { fontSize: t.font.head, fontWeight: '900', color: t.text } }, COMBO_NAME),
      // Two short lines, so Korean words never break in the middle on a narrow phone.
      h(Text, { numberOfLines: 1, style: { marginTop: 4, fontSize: t.font.body, lineHeight: 22, color: t.sub } },
        goals.flatMap((goal, i) => [i ? ' · ' : '', h(Text, { key: goal, style: { fontWeight: '900', color: t.point } }, goal)])),
      h(Text, { numberOfLines: 1, style: { fontSize: t.font.small, lineHeight: 22, color: t.sub } }, '목표별 추천 조합이 있어요')),
    h(View, { style: { borderRadius: t.radius.chip, paddingVertical: 8, paddingHorizontal: 14, backgroundColor: t.accent } },
      h(Text, { style: { fontSize: t.font.small, fontWeight: '900', color: t.text } }, '보기 ›')));
  return opacity ? h(Animated.View, { style: { opacity } }, pressable) : pressable;
}

/** Panel that rises from the bottom over the wall. It starts below the chip row so the chip stays visible and clickable. */
function ComboSheet({ top, theme, children }: { top: number; theme: ComboTheme; children?: ReactElement }): ReactElement {
  const React = require('react') as typeof import('react');
  const { Animated, Dimensions } = require('react-native') as typeof import('react-native');
  const slide = React.useRef<import('react-native').Animated.Value | null>(null);
  if (!slide.current) slide.current = new Animated.Value(0);
  // 0.6.5: the slide is driven from JS and, once it has finished, the transform is taken off the sheet altogether — a list inside a view that a native-driver animation has moved
  // did not react to swipes on an Android A32 (taps worked). The sheet is a state of its own (`settled`) that starts again each time the sheet opens (it is unmounted when closed).
  const [settled, setSettled] = React.useState(false);
  React.useEffect(() => {
    resetComboSheetProbe(); // TEMP-DIAG 0.6.5 (0.6.6 removes it)
    Animated.timing(slide.current!, { toValue: 1, duration: 220, useNativeDriver: false }).start((result?: { finished?: boolean }) => { if (!result || result.finished !== false) setSettled(true); });
  }, []);
  const translateY = slide.current.interpolate({ inputRange: [0, 1], outputRange: [Dimensions.get('window').height, 0] });
  return React.createElement(Animated.View, {
    onTouchStart: () => comboSheetProbe('container touchStart'), // TEMP-DIAG 0.6.5
    style: {
      position: 'absolute', left: 0, right: 0, bottom: 0, top, zIndex: 25, elevation: 25, overflow: 'hidden',
      borderTopLeftRadius: theme.radius.card, borderTopRightRadius: theme.radius.card, backgroundColor: theme.bg,
      ...(settled ? {} : { transform: [{ translateY }] }), ...theme.shadow,
    },
  }, children);
}

const withTimeout = <T,>(promise: Promise<T>, ms: number, fallback: T): Promise<T> => {
  let timer: ReturnType<typeof setTimeout> | undefined;
  return Promise.race([promise, new Promise<T>(resolve => { timer = setTimeout(() => resolve(fallback), ms); })]).finally(() => clearTimeout(timer));
};
const NOTICE_MS = 4500;

/**
 * What happened on one 하러 가기 tap, step by step, so a failure can be located without guessing: was there a bridge, did the
 * SDK list arrive (how many, or which error), which key was tried and how it was found, did the SDK take it. Public campaign data
 * only: no member, device or advertising id. The host decides whether and where to send it (`onDiagnostic`).
 */
export type ComboTapDiagnostic = {
  t: 'tap';
  /** the server's mission id (a campaign key when the server knows it, else a short hash) */
  mission: string;
  name: string;
  bridge: boolean;
  /** how many campaigns the SDK list returned (0 when it failed or was not asked) */
  listCount: number;
  listError?: string;
  /** first names of the SDK list, to see why a name did not match */
  listSample?: string[];
  /** where the key we tried came from: the server (`campaignKey` / a numeric id), a name match, the row id found in the list, or none */
  how: 'server_key' | 'name' | 'id_in_list' | 'none' | 'snapplay_id';
  key?: string;
  /** keys tried in all (the last one is described by `key` / `open`) */
  attempts: number;
  /** true: the SDK took the key. false: it refused or gave no answer in time. 'error': the call threw. 'skipped': nothing to try */
  open: boolean | 'error' | 'skipped';
  openError?: string;
  openMs?: number;
  copied?: boolean;
  /** milliseconds from the tap to the outcome */
  ms: number;
};
/**
 * What the app saw when it opened a campaign's detail page, as a hint for the server's own sold-out check (대표님 10/27 22:11):
 * `open_failed` = the SDK would not open it or gave no sign it did (`ms` = the wait; ~5000+ on iOS means no sign of opening),
 * `closed_fast` = it opened and was closed again within COMBO_CLOSED_FAST_MS (`ms` = how long it stayed). `platform` is 'ios' | 'android'.
 * Opening and closing quickly is also what a quick participation looks like, so this is a hint and nothing more.
 */
export type ComboDetailSignal = { result: 'open_failed' | 'closed_fast'; campaignKey: string; platform: string; ms: number };
/** What `onSheetShown` reports: the milliseconds the guide took to open, and how much it showed first. */
export type ComboSheetShown = { ms: number; tabs: number; rows: number; total: number };
/** A detail page that closes within this long after opening (ms) counts as `closed_fast`. */
export const COMBO_CLOSED_FAST_MS = 15_000;
/** After sending a detail signal, the combos are fetched again this long after (the server may answer with a `soldout` list). */
export const COMBO_SIGNAL_REFRESH_MS = 3000;
const short = (value: unknown, max = 80): string => {
  const e = value as { code?: unknown; message?: unknown } | null;
  const text = typeof value === 'string' ? value : e && (e.code || e.message) ? `${e.code ? String(e.code) + ': ' : ''}${String(e.message ?? '')}` : String(value);
  return text.replace(/[\u0000-\u001f\u007f]+/g, ' ').trim().slice(0, max);
};
/** Server key shapes: a real campaign key is a long number (the 12-hex hash ids are not keys). */
type ListResult = { list: CampaignInfo[]; error?: string };
const SLOW_REFUSAL_MS = 4500;
/** Fetching the combos again for `done` is skipped when the last fetch was this recent (ms). */
export const COMBO_REFRESH_GAP_MS = 2500;
const isCampaignKey = (value: string | undefined): value is string => !!value && /^\d{3,20}$/.test(value);

/** Space kept free below the popup card (px), above it (the chip row stays clear and tappable), and the least height the card is cut down to. */
const POPUP_EDGE = 16;
const POPUP_TOP = 44;
const POPUP_MIN_HEIGHT = 260;

/** How long after the wall has loaded the recommendation popup waits before it appears. */
export const COMBO_POPUP_DELAY_MS = 600;

/**
 * Recommendation popup in the middle of the wall, shown once a day after the Chance tab's wall has loaded: a big picture on top,
 * the sum as a large headline (「오늘 +5,965P 모을 수 있어요」), one subtitle line, a first-come notice, one wide button, and below it the
 * app's own ad (`ad`, 대표님 10/27 「네이티브 배너 광고 넣어」). It closes with the ✕ at the top right (no text link) or by tapping the dimmed
 * area. It scales in over a dimmed wall and sits under the chip (the chip stays visible and tappable). The card scrolls when it is
 * taller than the wall (a native ad is tall).
 */
function ComboPopup({ combos, theme, art, ad, onOpen, onClose }: {
  combos: TodayCombos; theme: ComboTheme; art?: import('react-native').ImageSourcePropType; ad?: () => ReactElement | null; onOpen: () => void; onClose: () => void;
}): ReactElement {
  const React = require('react') as typeof import('react');
  const { View, Text, Pressable, Image, Animated, ScrollView, Dimensions } = require('react-native') as typeof import('react-native');
  const h = React.createElement;
  const t = theme;
  const content = comboPopupContent(combos);
  const headline = popupHeadlineSizes(content);
  const grow = React.useRef<import('react-native').Animated.Value | null>(null);
  if (!grow.current) grow.current = new Animated.Value(0);
  React.useEffect(() => { Animated.timing(grow.current!, { toValue: 1, duration: 240, useNativeDriver: true }).start(); }, []);
  // The card may be as tall as the space it floats in (the wall area, not the whole screen): measured, with 86 % of the window until then.
  const [room, setRoom] = React.useState(0);
  const scale = grow.current.interpolate({ inputRange: [0, 1], outputRange: [0.88, 1] });
  const opacity = grow.current.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });
  const sparkle = (key: string, left: number | string, top: number, size: number, rotate: string, color: string) => h(View, {
    key, accessible: false, style: { position: 'absolute', left: left as number, top, width: size, height: size, borderRadius: 2, backgroundColor: color, transform: [{ rotate }] },
  });
  // The picture: the app's own art when it gives one, else a coin drawn from plain views.
  const coin = (size: number, key: string, style: import('react-native').ViewStyle = {}) => art
    ? h(Image, { key, source: art, resizeMode: 'contain', accessibilityIgnoresInvertColors: true, style: { width: size, height: size, ...(style as import('react-native').ImageStyle) } })
    : h(View, { key, accessible: false, style: { width: size, height: size, borderRadius: size / 2, borderWidth: Math.max(3, size / 12), borderColor: t.text, backgroundColor: t.accent, alignItems: 'center', justifyContent: 'center', ...style } },
      h(Text, { style: { fontSize: size * 0.42, fontWeight: '900', color: t.text } }, 'P'));
  return h(View, {
    key: 'popup', pointerEvents: 'box-none',
    onLayout: (event: import('react-native').LayoutChangeEvent) => { const height = Math.round(event.nativeEvent.layout.height); if (height > 0) setRoom(height); },
    style: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 22, elevation: 22, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28, paddingTop: POPUP_TOP, paddingBottom: POPUP_EDGE },
  },
    h(Pressable, {
      accessibilityRole: 'button', accessibilityLabel: '팝업 닫기', onPress: onClose,
      style: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.55)' },
    }),
    h(Animated.View, {
      accessibilityViewIsModal: true,
      style: { width: '100%', maxWidth: 320, maxHeight: room > 0 ? Math.max(POPUP_MIN_HEIGHT, room - POPUP_TOP - POPUP_EDGE) : Math.round(Dimensions.get('window').height * 0.86), borderRadius: 24, overflow: 'hidden', backgroundColor: t.card, opacity, transform: [{ scale }], ...t.shadow },
    },
      h(ScrollView, { bounces: false, showsVerticalScrollIndicator: false, style: { flexGrow: 0 } },
        // 대표님 10/27 22:27 「동전 칸 높이를 반으로」: 66 high (was 132), the coins half their size
        h(View, { accessible: false, style: { height: 66, alignItems: 'center', justifyContent: 'center', backgroundColor: t.accentSoft } },
          coin(20, 'coin-left', { position: 'absolute', left: 48, top: 34, opacity: 0.9 }),
          coin(20, 'coin-right', { position: 'absolute', right: 52, top: 10, opacity: 0.9 }),
          coin(48, 'coin-main'),
          sparkle('s1', 34, 13, 6, '45deg', t.accent), sparkle('s2', '74%', 40, 5, '45deg', t.accentText),
          sparkle('s3', 70, 50, 4, '45deg', t.accentText), sparkle('s4', '82%', 9, 7, '45deg', t.accent)),
        h(View, { style: { paddingHorizontal: 22, paddingTop: 20, paddingBottom: 20, alignItems: 'center' } },
          // One line (대표님 10/27 22:27): 「오늘 +5,965P 모을 수 있어요」 with the big number; sizes shrink together when it would not fit, and the
          // words and the number share one line height so the top of the digits is not cut off.
          h(Text, {
            accessibilityRole: 'header', numberOfLines: 1, adjustsFontSizeToFit: true, minimumFontScale: 0.6,
            style: { fontSize: headline.words, lineHeight: headline.line, fontWeight: '700', color: t.text, textAlign: 'center' },
          }, content.before, h(Text, { style: { fontSize: headline.amount, lineHeight: headline.line, fontWeight: '900', color: t.point } }, content.amount), content.after),
          content.sub ? h(Text, { style: { marginTop: 6, fontSize: 14, lineHeight: 20, color: t.sub, textAlign: 'center' } }, content.sub) : null,
          // Campaigns close when their places run out: said plainly, right under the number (a true statement, not a promise).
          h(View, { style: { marginTop: 10, borderRadius: t.radius.chip, backgroundColor: t.accentSoft, paddingVertical: 3, paddingHorizontal: 12 } },
            h(Text, { style: { fontSize: 12, lineHeight: 16, fontWeight: '700', color: t.accentText, textAlign: 'center' } }, content.notice)),
          h(Pressable, {
            accessibilityRole: 'button', accessibilityLabel: '추천 보기', onPress: onOpen,
            style: ({ pressed }: { pressed: boolean }): import('react-native').ViewStyle => ({
              alignSelf: 'stretch', height: 36, marginTop: 14, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: t.accent, opacity: pressed ? 0.85 : 1,
            }),
          }, h(Text, { style: { fontSize: 15, fontWeight: '800', color: t.text } }, '추천 보기')),
          // The app's ad (its own spacing: it should keep clear of the button above and leave no gap when it is not filled)
          ad ? ad() : null)),
      // ✕ stays put at the top right while the card scrolls
      h(Pressable, {
        accessibilityRole: 'button', accessibilityLabel: '닫기', onPress: onClose, hitSlop: 8,
        style: { position: 'absolute', top: 10, right: 10, width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.92)', borderWidth: 1, borderColor: t.line },
      }, h(Text, { accessible: false, style: { fontSize: 16, lineHeight: 20, fontWeight: '700', color: t.text } }, '✕'))));
}

/** Short message at the top ("신한 SOL페이" 를 찾아 주세요). Touches go through it. */
function ComboToast({ text, top, theme }: { text: string; top: number; theme: ComboTheme }): ReactElement {
  const React = require('react') as typeof import('react');
  const { View, Text } = require('react-native') as typeof import('react-native');
  return React.createElement(View, {
    pointerEvents: 'none',
    style: { position: 'absolute', left: 16, right: 16, top, zIndex: 40, elevation: 40, borderRadius: theme.radius.slot, paddingVertical: 12, paddingHorizontal: 16, backgroundColor: theme.text },
  }, React.createElement(Text, { style: { fontSize: theme.font.small, lineHeight: 22, fontWeight: '800', color: '#FFFFFF' } }, text));
}

export type ComboEntryProps = {
  /** 'chance': chip over the wall (mount it beside the wall inside the same container). 'home': optional banner. */
  placement: 'chance' | 'home';
  /** Where the combos come from: `url` (+ `headers`), or `load` = the app's own API call returning the parsed JSON body. */
  url?: string;
  headers?: Record<string, string>;
  load?: () => Promise<unknown>;
  /** Identifies who `load` asks for (member id / token). When it changes the previous member's rows are dropped at once. */
  loadKey?: string | number;
  usn?: string | null;
  theme?: ComboTheme;
  /** Screen work only: shows fixed example rows. Never set this in a release. */
  sample?: boolean;
  /** Takes over a mission tap completely. Without it the entry opens the campaign itself (see below). */
  onPressMission?: (mission: ComboMission, bundle: ComboBundle) => void;
  /** AsyncStorage-shaped store for the "done" marks (kept per member and per Korean day). Without it they last until the app closes. */
  storage?: ComboStorage;
  /** Copies the campaign name when a tap falls back to the list. Default: the 0.3.0 native bridge when this binary has it, else no copy. */
  copyText?: (text: string) => unknown;
  /** The native campaign bridge. Default: found automatically (null on binaries without it). Pass `null` to switch direct opening off. */
  campaigns?: CampaignApi | null;
  /** Gets the campaign list (key, name, reward) once it was read, e.g. to send it to the server for test members. */
  reportCampaigns?: (list: CampaignInfo[]) => unknown;
  /** Called after every 하러 가기 tap with what happened (see ComboTapDiagnostic). Sending it is the app's business. */
  onDiagnostic?: (diagnostic: ComboTapDiagnostic) => unknown;
  /**
   * 0.6.2 — the 찬스2 (SnapPlay) tab's own list: the parsed body of `GET offerwall/combos?source=snapplay` (same shape as the 찬스1 body; a row's `campaignKey` is the SnapPlay
   * `adv_id`). On the 찬스2 tab the chip, the sheet and the done marks use this list; a tap opens that ad through the SDK (`openAdItem`) and, when the SDK cannot, falls back to the
   * 찬스2 tab. Without it, or when the answer has no rows, the 찬스2 tab has no chip (the 찬스1 list is never shown over SnapPlay); a build without SnapPlay has no 찬스2 tab at all.
   * 찬스1 is not touched.
   */
  loadSnapPlay?: () => Promise<unknown>;
  /**
   * 0.6.2 — called each time the SnapPlay SDK's ad list is read from the phone (at most about once a minute; needs the server's `listPlacement`), with the normalized ads
   * (`advId`, `title`, `points` = the SDK's `user_pnt`, …). For an app that sends the list to its server, and the way to compare `points` with what SnapPlay shows. Optional.
   */
  onSnapPlayAds?: (ads: SnapPlayAd[]) => unknown;
  /**
   * Called (for every member, once per result and campaign key per visit) when the SDK would not open a campaign's detail page
   * (`open_failed`) or the page was closed again within 15 s (`closed_fast`): a sold-out campaign ends up here, but so can a slow load
   * or a quick participation, so the app only reports and never hides the row itself. The server decides (the `soldout` list in the
   * combos). Sending it is the app's business.
   */
  onDetailSignal?: (signal: ComboDetailSignal) => unknown;
  /**
   * How long the guide sheet took to open (0.3.15), for the app to log: called once per opening, after its first paint, with the milliseconds from the render
   * that opened it to two animation frames after the screen mounted, and what it showed first (`tabs`, `rows` = the first page of the tab that opened, `total` = the
   * campaigns in the document). Nothing is sent anywhere by the package; an app logs it (e.g. `console.log('[combos] sheet', info)`) to read on a device.
   */
  onSheetShown?: (info: ComboSheetShown) => void;
  /**
   * Free trials (0.3.11). The app sends the member's answer to the cancel-notice question (`POST offerwall/trials/consent`). Without this the
   * question is not asked and a trial campaign opens like any other.
   */
  onTrialConsent?: (campaignKey: string, agree: boolean) => unknown;
  /**
   * Called after 「안내 받고 참여하기」, before the answer is saved: the app makes sure the phone can show the cancel notices (asks for the notification permission,
   * sends the member to the system settings when it was refused and checks again when they come back, registers the push token) and says how it went.
   * The consent and the campaign go on whatever it answers; only the toast differs. Without it nothing is asked.
   */
  onTrialNotify?: () => Promise<TrialNotifyResult>;
  /** The member's own free-trial list (`GET offerwall/trials`, the whole body): gives the 「무료체험 확인」 button and its list. Without it neither exists. */
  loadTrials?: () => Promise<unknown>;
  /** 「했어요」 / 「아직」 on a trial row (`POST offerwall/trials/{key}/cancelled`). */
  onTrialCancelled?: (campaignKey: string, cancelled: boolean) => unknown;
  chipTop?: number;
  chipRight?: number;
  sheetTop?: number;
  /** Picture at the top of the recommendation popup (the app's coin art). Without it a coin is drawn from plain views. */
  popupArt?: import('react-native').ImageSourcePropType;
  /**
   * The app's own ad, drawn at the bottom of the recommendation popup under the 「추천 보기」 button (Eggmoney: its existing native ad card).
   * Give it its own top margin; return null (and no spacing) when there is nothing to show.
   */
  popupAd?: () => ReactElement | null;
};
/**
 * Chance tab: put it next to the wall inside one container, `<View style={{flex:1}}><OfferwallScreen/><ComboEntry placement="chance"/></View>`.
 * The chip floats over the wall's header row; tapping it raises the guide over the wall, tapping again (or 닫기) closes it
 * and the wall stays as it was. Home: a banner that opens the guide as a full screen. The server picks what shows
 * through `display`; the Chance tab keeps answering popup / push / link requests even when its chip is switched off.
 *
 * Tapping 하러 가기 on a row: with the native bridge the campaign's key is looked up (same name in the SDK's list, or the
 * server's id when it is a key) and its detail page opens. Otherwise, or when nothing is found, the name is shown at the
 * top (and copied when possible) and the plain list is revealed: the Chance tab closes the guide, Home opens the list.
 */
export function ComboEntry({
  placement, url, headers, load, loadKey, usn, theme = DEFAULT_COMBO_THEME, sample = false, onPressMission, storage, copyText, campaigns,
  reportCampaigns, onDiagnostic, onDetailSignal, onSheetShown, onTrialConsent, onTrialNotify, loadTrials, onTrialCancelled, chipTop, chipRight, sheetTop = COMBO_SHEET_TOP, popupArt, popupAd,
  loadSnapPlay, onSnapPlayAds,
}: ComboEntryProps): ReactElement | null {
  const React = require('react') as typeof import('react');
  const { Modal, Pressable, SafeAreaView, Dimensions } = require('react-native') as typeof import('react-native');
  const h = React.createElement;
  // 0.6.2: the Chance tab has one list per tab. 찬스1 (AdPopcorn) is the list this entry always had; 찬스2 (SnapPlay) has its own, loaded only when the build has SnapPlay and the server
  // turned it on (the provider is then in the list), and used only while that tab is up. While 찬스2 is up the AdPopcorn list is never shown (its missions open in the other SDK):
  // an app that gives no `loadSnapPlay`, or a server answer without rows, simply has no chip on that tab.
  const providers = useChanceProviders();
  const snapUsable = placement === 'chance' && providers.some(provider => provider.id === SNAPPLAY_PROVIDER_ID);
  const [chanceTab, setChanceTabState] = React.useState(getChanceTab);
  // 0.6.4: subscribe, then read the current value at once — the screen next to this entry sets these signals in its own effects, which can run before this subscription exists
  // (the first notification is then missed, and an equal value later notifies nobody). Reading what is already there closes that gap.
  React.useEffect(() => {
    if (placement !== 'chance') return undefined;
    setChanceTabState(getChanceTab());
    return onChanceTab(setChanceTabState);
  }, [placement]);
  const snapActive = snapUsable && chanceTab === SNAPPLAY_PROVIDER_ID;
  const adState = useTodayCombos({ url, headers, load, loadKey, sample });
  const snapState = useTodayCombos({ load: snapUsable ? loadSnapPlay : undefined, loadKey: `${loadKey ?? ''}:snapplay` });
  const state = snapActive ? snapState : adState;
  const scope = snapActive ? `${loadKey ?? ''}:snapplay` : loadKey;
  const [open, setOpen] = React.useState(false);
  // When the render that opened the guide began, for `onSheetShown` (cleared when it closes, so every opening is timed on its own).
  const openedAt = React.useRef<number | null>(null);
  if (!open) openedAt.current = null; else if (openedAt.current === null) openedAt.current = Date.now();
  // Hand ticks are kept per member and per campaign key (the server's key when it gave one, else the row id), with no daily reset.
  const marks = useDoneMissions({ storage, scope });
  const missionRows = missionRowsOf(state.combos);
  const markKey = (m: ComboMission) => m.campaignKey || m.id;
  const doneIds = new Set(missionRows.filter(m => marks.done.has(markKey(m))).map(m => m.id));
  const toggleDone = (id: string) => { const m = missionRows.find(x => x.id === id); marks.toggle(m ? markKey(m) : id); };
  const [notice, setNotice] = React.useState<string | null>(null);
  const noticeTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const campaignCache = React.useRef<{ key: string; promise: Promise<ListResult> } | null>(null);
  const latest = React.useRef({ campaigns, copyText, reportCampaigns, usn, placement, onDiagnostic, onDetailSignal, onTrialConsent, onTrialNotify, loadTrials, onTrialCancelled, combos: state.combos, refresh: state.refresh, snap: snapActive, onSnapPlayAds });
  latest.current = { campaigns, copyText, reportCampaigns, usn, placement, onDiagnostic, onDetailSignal, onTrialConsent, onTrialNotify, loadTrials, onTrialCancelled, combos: state.combos, refresh: state.refresh, snap: snapActive, onSnapPlayAds };
  const signalled = React.useRef(new Set<string>());
  const signalTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastOpened = React.useRef<{ key: string; at: number } | null>(null); // the detail page the SDK opened last, until it closes
  // Fetch the combos again (quietly) when the sheet opens, when the app comes back to the front, and when the SDK's detail screen closes:
  // that is when what the member just did shows up in the server's `done` list. At most once per few seconds; the first load counts.
  const lastRefresh = React.useRef(Date.now());
  const refreshNow = () => {
    const now = Date.now();
    if (now - lastRefresh.current < COMBO_REFRESH_GAP_MS) return;
    lastRefresh.current = now;
    try { latest.current.refresh(); } catch { /* a failed refresh keeps what is on screen */ }
  };
  /**
   * 대표님 10/27 (참여 한도 소진): the SDK shows its own 「참여 한도가 소진…」 message and tells the app nothing but "not opened" / "closed", so
   * the app reports what it saw (result, key, platform, wait) and looks at the server's combos again a few seconds later, where a `soldout`
   * list may now name the campaign. The app never hides the row on its own: a slow iOS load looks the same.
   */
  const signalDetail = (result: ComboDetailSignal['result'], key: string, ms: number) => {
    const once = `${result}:${key}`;
    if (signalled.current.has(once)) return;
    signalled.current.add(once);
    let platform = 'android';
    try { platform = (require('react-native') as typeof import('react-native')).Platform.OS === 'ios' ? 'ios' : 'android'; } catch { /* the default */ }
    try { void Promise.resolve(latest.current.onDetailSignal?.({ result, campaignKey: key, platform, ms })).catch(() => {}); } catch { /* reporting is best effort */ }
    if (signalTimer.current) clearTimeout(signalTimer.current);
    signalTimer.current = setTimeout(() => {
      lastRefresh.current = Date.now();
      try { latest.current.refresh(); } catch { /* a failed refresh keeps what is on screen */ }
    }, COMBO_SIGNAL_REFRESH_MS);
  };
  React.useEffect(() => { if (open) refreshNow(); }, [open]);
  React.useEffect(() => {
    let subscription: { remove(): void } | undefined;
    try {
      const { AppState } = require('react-native') as typeof import('react-native');
      subscription = AppState?.addEventListener?.('change', (next: string) => { if (next === 'active') refreshNow(); });
    } catch { /* no AppState: the sheet-open refresh still works */ }
    return () => { try { subscription?.remove(); } catch { /* ignore */ } };
  }, []);
  React.useEffect(() => addOfferwallNativeListener(event => {
    if (!event || event.type !== 'detailClosed') return;
    const opened = lastOpened.current;
    lastOpened.current = null;
    if (opened) { const stayed = Date.now() - opened.at; if (stayed <= COMBO_CLOSED_FAST_MS) signalDetail('closed_fast', opened.key, stayed); }
    refreshNow();
  }), []);
  const mode = placement === 'chance' ? state.combos?.display.chance ?? 'chip' : state.combos?.display.home ?? 'off';
  // (the 찬스2 tab has no chip until the server sent rows: an empty chip is never shown)
  const shown = placement === 'chance' ? mode === 'chip' && !!state.combos && (!snapActive || hasComboRows(state.combos)) : mode === 'banner' && !!state.combos;
  const listening = placement === 'chance' || mode !== 'off';
  // Blink until the guide was opened once today (by anyone: chip, banner, popup); then rest until the next Korean day.
  const seen = useSeenToday({ storage, scope, date: state.combos?.date });
  const blink = usePulse(shown && !open && seen.seen === false);
  // The recommendation popup: once a day per member, after the Chance tab's wall has loaded, unless the guide was already opened
  // today (by the chip, a main popup, a push) or this very visit. Server `display.popup: 'off'` turns it off.
  const popupSeen = useSeenToday({ storage, scope, date: state.combos?.date, keyOf: popupStorageKey });
  const [popup, setPopup] = React.useState(false);
  const [wallReady, setWallReady] = React.useState(isWallLoaded);
  // 0.5.1: the 「찬스1 · 찬스2」 tab row above the wall pushes everything down by its height — the chip row, the sheet and the toast follow
  const [tabInset, setTabInset] = React.useState(getChanceTabInset);
  React.useEffect(() => {
    if (placement !== 'chance') return undefined;
    setTabInset(getChanceTabInset());
    return onChanceTabInset(setTabInset);
  }, [placement]);
  const inset = placement === 'chance' ? tabInset : 0;
  const everOpened = React.useRef(false);
  const popupGiven = React.useRef(false); // at most one popup per visit (entry mount), even when it is shown on every visit
  React.useEffect(() => {
    if (placement !== 'chance') return undefined;
    setWallReady(isWallLoaded());
    return onWallState(setWallReady);
  }, [placement]);
  const popupMode = state.combos?.display.popup; // 'off' | 'always' | undefined (once a day)
  // (nothing to recommend while an iPhone list is being prepared with no rows: no popup, and the day's one popup is not used up)
  const popupDue = placement === 'chance' && !snapActive && shown && hasComboRows(state.combos) && popupMode !== 'off' && !open && !popup && !everOpened.current && !popupGiven.current
    && (popupMode === 'always' || (seen.seen === false && popupSeen.seen === false));
  const popupDueNow = React.useRef(false);
  popupDueNow.current = popupDue;
  React.useEffect(() => {
    if (!popupDue || !wallReady) return;
    const timer = setTimeout(() => {
      if (!popupDueNow.current) return;
      popupGiven.current = true;
      setPopup(true);
      popupSeen.markSeen();
    }, COMBO_POPUP_DELAY_MS);
    return () => clearTimeout(timer);
  }, [popupDue, wallReady]);
  // Opening the guide (chip, popup button, main popup, push) counts as seen today for the blink AND for the popup.
  React.useEffect(() => {
    if (!open) return;
    everOpened.current = true;
    setPopup(false);
    if (state.combos) { seen.markSeen(); popupSeen.markSeen(); }
  }, [open, !!state.combos]);
  React.useEffect(
    () => listening ? listenForComboRequests({ priority: placement === 'chance' ? 2 : 1, open: () => setOpen(true) }) : undefined,
    [listening, placement]);
  React.useEffect(() => () => {
    if (noticeTimer.current) clearTimeout(noticeTimer.current);
    if (signalTimer.current) clearTimeout(signalTimer.current);
  }, []);
  // 0.6.2: another tab was picked while the sheet / popup was up — they belong to the tab they were opened on, so they close (the tab row is above the sheet and stays tappable).
  const lastSnapActive = React.useRef(snapActive);
  React.useEffect(() => {
    if (lastSnapActive.current === snapActive) return;
    lastSnapActive.current = snapActive;
    setOpen(false); setPopup(false); setTabPopup(false); setTrialsOpen(false); setNotice(null);
  }, [snapActive]);
  // 0.6.2: an app that sends the SnapPlay ad list to its server gets it as soon as the phone can read it, and again about every hour (only when it passed `onSnapPlayAds`).
  const wantsAds = snapUsable && !!onSnapPlayAds && !!usn;
  React.useEffect(() => {
    if (!wantsAds) return;
    let live = true;
    const run = () => {
      void readSnapPlayAds({ usn: usn! }).then(result => {
        if (!live || !result.ok || result.cached) return;
        try { void Promise.resolve(latest.current.onSnapPlayAds?.(result.ads)).catch(() => {}); } catch { /* the app's upload must not break the screen */ }
      }).catch(() => {});
    };
    run();
    const timer = setInterval(run, 60 * 60 * 1000);
    return () => { live = false; clearInterval(timer); };
  }, [wantsAds, usn]);

  const bridge = (): CampaignApi | null => (latest.current.campaigns === undefined ? nativeCampaignApi() : latest.current.campaigns);
  /** The SDK's current campaigns, read once per member (and again after an empty result). Keeps WHY it was empty. */
  const campaignList = (): Promise<ListResult> => {
    const key = String(loadKey ?? '');
    if (campaignCache.current?.key === key) return campaignCache.current.promise;
    const api = bridge();
    if (!api) return Promise.resolve({ list: [] });
    const promise: Promise<ListResult> = withTimeout(
      api.list().then((list): ListResult => ({ list }), (error): ListResult => ({ list: [], error: short(error) })),
      4000, { list: [], error: 'timeout' } as ListResult,
    ).then(result => {
      if (!result.list.length && campaignCache.current?.promise === promise) campaignCache.current = null; // ask again next time
      else if (result.list.length) { try { latest.current.reportCampaigns?.(result.list); } catch { /* reporting is best effort */ } }
      return result;
    });
    campaignCache.current = { key, promise };
    return promise;
  };
  // Warm the list when the guide opens, so a tap that needs it does not wait.
  React.useEffect(() => { if (open && !snapActive && bridge()) void campaignList(); }, [open]);

  const say = (text: string) => {
    if (noticeTimer.current) clearTimeout(noticeTimer.current);
    setNotice(text);
    noticeTimer.current = setTimeout(() => setNotice(null), NOTICE_MS);
  };
  /**
   * Order, as asked by 대표님 (「해당 미션 페이지로 무조건 바로」): 1) the server's key (`campaignKey`, or a numeric mission id) goes
   * straight to the SDK without waiting for any list, 2) the same name in the SDK's list, 3) the row id when it is in the list,
   * 4) the fallback (name at the top, copied, plain list). Every tap reports what happened through `onDiagnostic`.
   */
  // ---- free trials: the cancel-notice question before a trial's detail page, and the member's own list ----
  const answered = React.useRef(new Map<string, boolean>()); // this visit's answers (lower-case key), until the server's `trial_consent` has them
  // The cancel-notice question is asked once, when the member walks into the 무료체험 tab (대표님 10/27 23:14) — not on each row. 「해지 알림 켜고 참여하기」 is kept on the
  // device; after it a tap on a trial row saves that campaign's consent by itself and opens it. 「괜찮아요」 = not again today.
  const noticeAgreed = useTrialNoticeAgreed({ storage, scope: loadKey });
  const noticeDeclined = useSeenToday({ storage, scope: loadKey, date: state.combos?.date, keyOf: trialNoticeDeclineKey });
  const [tabPopup, setTabPopup] = React.useState(false);
  const trialGate = React.useRef({ ask: false, agreed: false });
  // 0.6.1: the server can choose when the tab asks (display.trial_notice): 'always' = on every walk-in, 'daily' = the first walk-in of each Korean day, absent = as in 0.3.13.
  const noticeRule = state.combos?.display.trialNotice;
  const askNow = noticeRule === 'always' ? true : noticeRule === 'daily' ? noticeDeclined.seen === false : noticeAgreed.agreed === false && noticeDeclined.seen === false;
  trialGate.current = { ask: !!onTrialConsent && askNow, agreed: noticeAgreed.agreed === true };
  const onTrialTab = () => { if (trialGate.current.ask) setTabPopup(true); };
  const answerTabPopup = async (answer: ConsentAnswer) => {
    setTabPopup(false);
    if (noticeRule === 'daily') noticeDeclined.markSeen();   // once a day, whatever the answer
    if (answer !== 'agree') { noticeDeclined.markSeen(); return; }
    // first make sure the phone can show the notices (the app asks for the permission / opens the settings / registers the push token), then keep the choice
    let notify: TrialNotifyResult = 'on';
    if (latest.current.onTrialNotify) { try { notify = await latest.current.onTrialNotify(); } catch { notify = 'none'; } }
    noticeAgreed.setAgreed();
    say(notify === 'on' ? COMBO_CONSENT_TOAST : COMBO_CONSENT_TOAST_OFF);
  };
  const [trialsOpen, setTrialsOpen] = React.useState(false);
  const [trialsFocus, setTrialsFocus] = React.useState<string | undefined>(undefined);
  const [mine, setMine] = React.useState<{ items: MyTrial[] | null; loading: boolean; failed: boolean }>({ items: null, loading: false, failed: false });
  const mineRequest = React.useRef(0);
  const loadMine = () => {
    const load = latest.current.loadTrials;
    if (!load) return;
    const mine_ = ++mineRequest.current;
    setMine(m => ({ ...m, loading: true, failed: false }));
    Promise.resolve().then(load).then(
      body => {
        if (mine_ !== mineRequest.current) return;
        const list = parseMyTrials(body);
        setMine(m => (list ? { items: list, loading: false, failed: false } : { items: m.items, loading: false, failed: true }));
      },
      () => { if (mine_ === mineRequest.current) setMine(m => ({ ...m, loading: false, failed: true })); },
    );
  };
  React.useEffect(() => { if (trialsOpen) loadMine(); }, [trialsOpen]);
  const openTrials = (key?: string) => { setTrialsFocus(key); setOpen(false); setPopup(false); setTrialsOpen(true); };
  const trialsAvailable = !!loadTrials && placement === 'chance' && !snapActive; // free trials are 찬스1's
  React.useEffect(() => (trialsAvailable ? listenForTrialRequests({ priority: 2, open: openTrials }) : undefined), [trialsAvailable]);
  const markCancelled = (trial: MyTrial, cancelled: boolean) => {
    setMine(m => ({ ...m, items: m.items ? m.items.map(x => (x.campaignKey === trial.campaignKey ? { ...x, cancelled } : x)) : m.items }));
    let sent: unknown;
    try { sent = latest.current.onTrialCancelled?.(trial.campaignKey, cancelled); } catch { sent = Promise.reject(new Error('send')); }
    void Promise.resolve(sent).catch(() => { loadMine(); }); // a failed send: show what the server really has
  };
  const handleMission = async (mission: ComboMission, bundle: ComboBundle, opts: { skipConsent?: boolean } = {}) => {
    if (onPressMission) { onPressMission(mission, bundle); return; }
    // After 「해지 알림 켜고 참여하기」 (kept on the device) a free-trial campaign's consent is saved by itself, with no question, and the detail page opens at once.
    // Without that choice nothing is asked or saved here: the question belongs to the tab.
    if (!opts.skipConsent && latest.current.onTrialConsent && trialGate.current.agreed) {
      const trialKey = [mission.campaignKey, isCampaignKey(mission.id) ? mission.id : undefined].find(k => needsTrialConsent(latest.current.combos, k, answered.current));
      if (trialKey) {
        answered.current.set(trialKey.toLowerCase(), true);
        try { void Promise.resolve(latest.current.onTrialConsent?.(trialKey, true)).catch(() => {}); } catch { /* the choice is kept for this visit anyway */ }
      }
    }
    const started = Date.now();
    const snap = latest.current.snap;
    const api = snap ? null : bridge(); // the AdPopcorn campaign bridge belongs to 찬스1
    const diag: ComboTapDiagnostic = { t: 'tap', mission: mission.id, name: mission.name, bridge: !!api, listCount: 0, how: 'none', attempts: 0, open: 'skipped', ms: 0 };
    const tried = new Set<string>();
    let unsure = false;
    /**
     * Gives one key to the SDK. true = it took it (the guide stays open for the next campaign).
     * A "no" that took about as long as the native timeout may be a page that is still loading, so no second page is opened after it.
     */
    const attempt = async (key: string, how: ComboTapDiagnostic['how']): Promise<boolean> => {
      if (!api || unsure || tried.has(key)) return false;
      tried.add(key);
      diag.how = how; diag.key = key; diag.attempts = tried.size; delete diag.openError;
      const at = Date.now();
      try { diag.open = (await api.open(key)) ? true : false; } catch (error) { diag.open = 'error'; diag.openError = short(error); }
      diag.openMs = Date.now() - at;
      if (diag.open === false) signalDetail('open_failed', key, diag.openMs);
      else if (diag.open === true) lastOpened.current = { key, at: Date.now() };
      if (diag.open === false && diag.openMs >= SLOW_REFUSAL_MS) unsure = true;
      return diag.open === true;
    };
    const finish = (extra: Partial<ComboTapDiagnostic> = {}) => {
      Object.assign(diag, extra, { ms: Date.now() - started });
      try { void Promise.resolve(latest.current.onDiagnostic?.({ ...diag })).catch(() => {}); } catch { /* diagnostics never break the tap */ }
    };
    if (snap) {
      // 0.6.2, 찬스2: the row's key is the SnapPlay adv_id; the SDK opens that ad itself. Not in the SDK's fresh list = closed (reported as a hint, the server decides); anything else that
      // keeps it from opening (no list placement, an old plugin, a failed list) falls through to the plain fallback below: the name is shown, copied, and the sheet closes onto the 찬스2 tab.
      const key = [mission.campaignKey, isCampaignKey(mission.id) ? mission.id : undefined].find(isCampaignKey);
      if (key) {
        diag.how = 'snapplay_id'; diag.key = key; diag.attempts = 1;
        const at = Date.now();
        let result: SnapPlayOpenResult;
        try { result = await openSnapPlayAd(key, latest.current.usn ? { usn: latest.current.usn } : undefined); } catch { result = { ok: false, reason: 'sdk_error', listCount: 0 }; }
        diag.openMs = Date.now() - at; diag.listCount = result.listCount;
        if (result.ok) { diag.open = true; finish(); return; }
        diag.open = result.reason === 'sdk_error' ? 'error' : false; diag.openError = result.reason;
        if (result.reason === 'gone') {
          signalDetail('open_failed', key, diag.openMs);
          finish();
          say(`"${mission.name}" 는 마감됐어요 · 다른 미션을 골라 주세요`);
          return;
        }
      }
    }
    if (api) {
      // 1) the server's key: no list needed
      for (const key of [mission.campaignKey, isCampaignKey(mission.id) ? mission.id : undefined]) {
        if (key && await attempt(key, 'server_key')) { finish(); return; }
      }
      // 2) names / ids from the SDK's own list (it is only a part of the offerwall, so a miss is normal)
      const { list, error } = await withTimeout(campaignList(), 2500, { list: [], error: 'timeout' } as ListResult);
      diag.listCount = list.length;
      if (error) diag.listError = error;
      if (list.length) diag.listSample = list.slice(0, 5).map(c => c.name.slice(0, 40));
      const keys = new Set(list.map(c => c.campaignKey));
      const byName = findCampaignKey(list, mission.name);
      if (byName && await attempt(byName, 'name')) { finish(); return; }
      if (keys.has(mission.id) && await attempt(mission.id, 'id_in_list')) { finish(); return; }
    }
    // 3) fallback
    const copy = latest.current.copyText ?? nativeCopyText();
    let copied = false;
    if (copy) { try { copied = (await copy(mission.name)) !== false; } catch { copied = false; } }
    // 0.4.0: with nothing to copy with (a binary without the module, no `copyText`) no copy is tried, and the member is told to remember the name instead
    finish(copy ? { copied } : {});
    say(`"${mission.name}" 를 찾아 주세요${copy ? (copied ? ' · 이름을 복사했어요' : '') : ' · 이름을 기억해 두세요'}`);
    if (latest.current.placement === 'chance') setOpen(false); // the wall is right below
    else if (latest.current.usn) { const wall = latest.current.usn; setTimeout(() => { openOfferwall({ usn: wall }); }, 700); }
  };

  const close = () => setOpen(false);
  const guide = (variant: 'page' | 'sheet') => h(ComboGuideScreen, {
    combos: state.combos, loading: state.status === 'loading', onClose: close, onPressMission: handleMission, usn, theme, variant,
    done: doneIds, onToggleDone: toggleDone,
    onTrialTab,
    // the guide's first paint: how long since the render that opened it (only when the app asked)
    ...(onSheetShown ? { onShown: (first: { tabs: number; rows: number }) => {
      const start = openedAt.current;
      if (start === null) return;
      try { onSheetShown({ ms: Math.max(0, Date.now() - start), tabs: first.tabs, rows: first.rows, total: new Set(missionRowsOf(state.combos).map(m => m.campaignKey || m.id)).size }); } catch { /* the app's log must not break the sheet */ }
    } } : {}),
    onPressTrial: (trial: ComboTrial) => {
      const row = trialMissions(state.combos).find(m => m.id === trial.campaignKey);
      if (row) void handleMission(row, { goal: 0, missions: [row], total: row.points });
    },
  });
  // 「무료체험 확인」 is there when the app can load the list and the server turned free trials on (it sent trials or trial keys)
  const trialsChip = shown && trialsAvailable && !!state.combos && !!(state.combos.trials?.length || state.combos.trialKeys?.length);
  const chipFit = trialsChip ? comboChipFit(Dimensions.get('window').width, chipRight ?? COMBO_CHIP_RIGHT) : null;
  const consentView = tabPopup ? h(TrialConsentPopup, { key: 'consent', theme, onAnswer: (answer: ConsentAnswer) => { void answerTabPopup(answer); } }) : null;
  if (!shown && !open && !notice && !popup && !trialsOpen && !tabPopup) return null;
  if (placement === 'home') {
    return h(React.Fragment, null,
      shown && state.combos && hasComboRows(state.combos) ? h(ComboBanner, { combos: state.combos, onPress: () => setOpen(true), theme, opacity: blink }) : null,
      open ? h(Modal, { visible: true, animationType: 'slide', onRequestClose: close },
        h(SafeAreaView, { style: { flex: 1, backgroundColor: theme.bg } }, guide('page'),
          notice ? h(ComboToast, { text: notice, top: 8, theme }) : null,
          consentView)) : null,
      !open ? consentView : null);
  }
  return h(React.Fragment, null,
    open ? h(Pressable, {
      key: 'backdrop', accessibilityRole: 'button', accessibilityLabel: '닫기', onPress: close,
      style: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 20, elevation: 20, backgroundColor: 'rgba(0,0,0,0.3)' },
    }) : null,
    open ? h(ComboSheet, { key: 'sheet', top: sheetTop + inset, theme }, guide('sheet')) : null,
    trialsOpen ? h(Pressable, {
      key: 'trials-backdrop', accessibilityRole: 'button', accessibilityLabel: '닫기', onPress: () => setTrialsOpen(false),
      style: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 20, elevation: 20, backgroundColor: 'rgba(0,0,0,0.3)' },
    }) : null,
    trialsOpen ? h(ComboSheet, { key: 'trials-sheet', top: sheetTop + inset, theme },
      h(ComboTrialsScreen, {
        items: mine.items, loading: mine.loading, failed: mine.failed, theme, focusKey: trialsFocus, onRetry: loadMine,
        onClose: () => setTrialsOpen(false), onCancelled: markCancelled,
        // a row of my own list opens its campaign straight away (these were joined already: no consent question again)
        onOpen: (trial: MyTrial) => { void handleMission({ id: trial.campaignKey, name: trial.name, points: trial.points ?? 1, todo: '', level: 'easy', campaignKey: trial.campaignKey }, { goal: 0, missions: [], total: 0 }, { skipConsent: true }); },
      })) : null,
    popup && !open && !trialsOpen && state.combos ? h(ComboPopup, { combos: state.combos, theme, art: popupArt, ad: popupAd, onOpen: () => { setPopup(false); setOpen(true); }, onClose: () => setPopup(false) }) : null,
    shown ? h(ComboChip, {
      key: 'chip', open, theme, top: (chipTop ?? COMBO_CHIP_TOP) + inset, right: chipRight, opacity: blink, fit: chipFit ?? undefined,
      before: trialsChip && chipFit ? h(ComboTrialsChip, { open: trialsOpen, theme, fit: chipFit, onPress: () => { if (trialsOpen) setTrialsOpen(false); else openTrials(); } }) : null,
      onPress: () => { setTrialsOpen(false); setOpen(o => !o); },
    }) : null,
    notice ? h(ComboToast, { key: 'notice', text: notice, top: sheetTop + inset + 8, theme }) : null,
    consentView);
}
